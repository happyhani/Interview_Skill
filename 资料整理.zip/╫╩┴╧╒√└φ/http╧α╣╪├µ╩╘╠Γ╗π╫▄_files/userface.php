document.write("<img src=\"http://ucenter.51cto.com/avatar.php?uid=10798695&size=middle\" id=userface>");
